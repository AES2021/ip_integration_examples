

/***************************** Include Files *******************************/
#include "myip_multiplier.h"

/************************** Function Definitions ***************************/
